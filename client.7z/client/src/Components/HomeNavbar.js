import React from 'react';
import { Link } from 'react-router-dom';
import './HomeNavbar.css';
import logo from "./crafttips.png";

function HomeNavbar(props) {
  const { loggedIn, onLogout } = props;

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <Link to="/" className="navbar-logo"><img src={logo}/></Link>
      </div>
      <div className="navbar-right">
        <Link to="/about" className="navbar-item">About</Link>
        <Link to="/services" className="navbar-item">Services</Link>
        {loggedIn ? (
          <div className="navbar-user">
            <span className="navbar-username">{props.username}</span>
            <button onClick={onLogout} className="navbar-button">Logout</button>
          </div>
        ) : (
          <Link to="/login" className="navbar-button">Login</Link>
        )}
      </div>
    </nav>
  );
}

export default HomeNavbar;
