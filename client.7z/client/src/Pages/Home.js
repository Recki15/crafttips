import React from 'react'
import HomeNavbar from '../Components/HomeNavbar'

export const Home = () => {
  return (
    <>
        <HomeNavbar/>
    </>
  )
}
