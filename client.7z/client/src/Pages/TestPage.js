import React from 'react'

export const TestPage = () => {
  return (
    <>
        <h1>Teszt-elek</h1>
    </>
  )
}
